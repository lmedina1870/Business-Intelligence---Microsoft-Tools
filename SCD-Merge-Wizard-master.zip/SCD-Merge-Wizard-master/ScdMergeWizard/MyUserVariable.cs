﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScdMergeWizard
{
    public class MyUserVariable
    {
        public string Name;
        public string ColumnName;
        public string DataType;
        public string Definition;
        public string Value;
    }
}
