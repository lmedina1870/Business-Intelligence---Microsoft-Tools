## [4.3.0] - 2020-08-06
* Added space before OR/AND in a condition statement (#9)
* Change: List of tables is sorted now (#2)
